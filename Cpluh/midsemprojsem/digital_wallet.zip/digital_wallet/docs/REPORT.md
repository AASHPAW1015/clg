# Digital Wallet System — Mid-Semester Project Report

**Subject:** Object-Oriented Programming with C++  
**Project Title:** Blockchain-Inspired Digital Wallet System  
**Language & Tools:** C++17, g++ Compiler, SHA-256 Hashing, Terminal CLI  

---

## 1. Introduction to the Case Study

Digital payment systems have become an essential part of modern life, with platforms like Paytm, Google Pay, and PhonePe handling millions of transactions daily. These systems must ensure **security** (PINs are never stored as plain text), **data integrity** (transactions cannot be tampered with), and **persistence** (data survives even after the application is closed).

This project implements a simplified **Digital Wallet System** using C++ that demonstrates how such systems work under the hood. The application allows users to create wallets, securely log in using hashed PINs, deposit and transfer funds, and view their complete transaction history — all stored using a blockchain-inspired ledger system.

The project focuses heavily on **Object-Oriented Programming (OOP)** principles including **Inheritance**, **Encapsulation**, **Abstraction**, and **Polymorphism**, while also demonstrating practical use of C++ features such as **file handling**, **vectors**, **maps**, **constructors**, and **hashing algorithms**.

---

## 2. Problem Statement / Case Background (Abstract)

### Problem Statement
Design and implement a command-line Digital Wallet System in C++ that allows multiple users to:
- Create secure wallets with hashed PIN authentication
- Deposit and transfer funds between wallets
- View transaction history and a blockchain-style ledger
- Persist all data across application restarts using file I/O

### Background
Traditional banking systems rely on centralized databases to store account balances. In contrast, blockchain-based systems like Bitcoin derive balances by scanning the entire transaction history — no single "balance" number is stored anywhere. This project adopts the blockchain approach: **balances are computed, never stored**, by scanning the chain of all recorded transactions.

The system uses **SHA-256 hashing** (an industry-standard cryptographic algorithm) for two critical purposes:
1. **PIN Security:** User PINs are hashed before storage, so even if the data file is accessed, the raw PIN cannot be recovered.
2. **Data Integrity:** Each block in the ledger contains a hash of the previous block, creating an unbreakable chain. If any past transaction is tampered with, the hash chain would break, making fraud detectable.

---

## 3. Problem Statement / Case Study Design

### 3.1 System Architecture

The system is organized into the following components:

| Component | Files | Purpose |
|-----------|-------|---------|
| **Crypto Utility** | `sha256.h`, `sha256.cpp` | SHA-256 hashing (open-source, NIST FIPS 180-4) |
| **Transaction** | `Transaction.h`, `Transaction.cpp` | Stores sender, receiver, amount, timestamp, and a unique transaction hash |
| **Block** | `Block.h`, `Block.cpp` | Groups transactions together with a hash linking to the previous block |
| **Ledger** | `Ledger.h`, `Ledger.cpp` | The blockchain — mines blocks, computes balances, retrieves history |
| **Account (Base)** | `Account.h`, `Account.cpp` | Base class with `name` and `walletID` (demonstrates Inheritance) |
| **Wallet (Derived)** | `Wallet.h`, `Wallet.cpp` | Derived from Account; adds private `hashedPin` (demonstrates Encapsulation) |
| **Main Application** | `main.cpp` | Entry point — handles UI, menus, file saving/loading, and global data |

### 3.2 OOP Principles Used

| Principle | Where It Is Used |
|-----------|-----------------|
| **Inheritance** | `Wallet` inherits from `Account` (protected members `name`, `walletID`) |
| **Encapsulation** | `hashedPin` is `private` in Wallet — only accessible via `verifyPin()` |
| **Abstraction** | Header files (`.h`) expose only the interface; implementation is hidden in `.cpp` files |
| **Constructor Overloading** | `Transaction` and `Block` have two constructors each — one for creating new objects, one for loading from file |

### 3.3 Data Flow Diagram

```
User Input (Terminal)
        │
        ▼
   ┌─────────┐
   │ main.cpp │ ◄── Global Variables: map<string,Wallet>, Ledger
   └────┬────┘
        │
   ┌────┴─────────────────────────┐
   │                              │
   ▼                              ▼
┌──────────┐              ┌──────────────┐
│ Wallet   │              │   Ledger     │
│ (login,  │              │ (addTx,      │
│  signup) │              │  mineBlock,  │
└──────────┘              │  getBalance) │
                          └──────┬───────┘
                                 │
                          ┌──────┴───────┐
                          │    Block     │
                          │ (contains    │
                          │ Transactions)│
                          └──────────────┘
                                 │
                          ┌──────┴───────┐
                          │  SHA-256     │
                          │ (hashing)    │
                          └──────────────┘
```

### 3.4 User Flow

```
Main Menu → [1] Sign Up / [2] Log In / [3] Exit
  │
  ├─[1] Sign Up: Enter name + PIN → PIN hashed → Wallet ID generated → Saved to file
  │
  └─[2] Log In → Dashboard:
       [1] Check Balance
       [2] Deposit Funds
       [3] Transfer Funds
       [4] Transaction History
       [5] View Blockchain Ledger
       [6] Log Out
```

---

## 4. Methods & Algorithms / Technology Applied

### 4.1 SHA-256 Hashing Algorithm
SHA-256 (Secure Hash Algorithm 256-bit) is a cryptographic function that converts any input string into a fixed-length 64-character hexadecimal output. It is:
- **One-way:** You cannot reverse the hash to get the original input
- **Deterministic:** The same input always produces the same hash
- **Collision-resistant:** It is practically impossible for two different inputs to produce the same hash

**Usage in this project:**
```cpp
string hashedPin = sha256("1234");
// Output: "03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4"
```

### 4.2 Blockchain-Inspired Ledger
Each `Block` contains:
- An **index** (position in the chain)
- A **timestamp** (when it was mined)
- A **vector of Transactions** (the actual data)
- A **previousHash** (linking it to the block before it)
- A **hash** (computed from all the above fields)

The hash of each block depends on the hash of the previous block, creating an **unbreakable chain**. If someone tampers with Block 2, the hash of Block 2 changes, which means Block 3's `previousHash` no longer matches — the entire chain after the tampering point becomes invalid.

### 4.3 Balance Computation (No Stored Balances)
Instead of storing a balance number, the system scans the **entire blockchain** to compute a wallet's balance:
```cpp
double Ledger::getBalance(string walletID) {
    double balance = 0;
    // Loop through every block in the chain
    // For each transaction: if walletID is the receiver, add amount
    //                       if walletID is the sender, subtract amount
    return balance;
}
```
This method is used by real cryptocurrencies like Bitcoin.

### 4.4 File Persistence with Pipe-Delimited Format
All data is saved to `wallet_data.dat` using C++ `ofstream` (for writing) and `ifstream` (for reading). Data fields are separated by pipe `|` characters:
```
WALLETS
2
W-a1b2c3d4|Aashish|03ac674216f3e15c...
W-e5f6g7h8|John|5e884898da28047151...
BLOCKCHAIN
3
0|2026-03-10 15:30:00|0|abc123...|0
1|2026-03-10 15:31:00|abc123...|def456...|1
SYSTEM|W-a1b2c3d4|1000.00|2026-03-10 15:31:00|tx789...
```

### 4.5 Technologies Used

| Technology | Purpose |
|-----------|---------|
| C++17 | Core programming language |
| g++ Compiler | Compilation and linking |
| STL `vector` | Dynamic arrays for storing Transactions and Blocks |
| STL `map` | Dictionary for fast wallet lookup by ID |
| STL `fstream` | File reading and writing for persistence |
| STL `sstream` | String manipulation and parsing |
| SHA-256 (Open-Source) | Cryptographic hashing (NIST FIPS 180-4) |
| ANSI Escape Codes | Terminal colors and UI styling |

---

## 5. Implementation Details and Snapshots

### 5.1 File Structure (894 total lines of code)

| File | Lines | Description |
|------|-------|-------------|
| `main.cpp` | 325 | Application logic, UI, file I/O, global variables |
| `sha256.cpp` | 168 | SHA-256 implementation (open-source) |
| `Ledger.cpp` | 86 | Blockchain logic: mining, balance computation |
| `Ledger.h` | 50 | Ledger interface declaration |
| `Block.cpp` | 43 | Block construction and hashing |
| `Block.h` | 38 | Block interface declaration |
| `Transaction.cpp` | 40 | Transaction creation and hashing |
| `Transaction.h` | 35 | Transaction interface declaration |
| `Wallet.cpp` | 25 | PIN verification, wallet construction |
| `Wallet.h` | 30 | Wallet interface (inherits from Account) |
| `Account.cpp` | 12 | Base class constructor |
| `Account.h` | 23 | Base class with protected members |
| `sha256.h` | 19 | SHA-256 function declaration |

### 5.2 Compilation

All source files are compiled together using the following command:
```bash
g++ -std=c++17 sha256.cpp Transaction.cpp Block.cpp Account.cpp Wallet.cpp Ledger.cpp main.cpp -o wallet_app
```

### 5.3 Application Snapshots

> **Note:** Replace the descriptions below with actual screenshots of the running application.

1. **Main Menu** — Shows the welcome screen with Sign Up, Log In, and Exit options.
2. **Wallet Creation** — Shows the successful creation of a new wallet with a generated Wallet ID.
3. **Dashboard** — Shows the logged-in dashboard with all 6 menu options.
4. **Deposit** — Shows a successful deposit with the transaction hash.
5. **Transfer** — Shows a successful fund transfer between two wallets.
6. **Transaction History** — Shows the table of all transactions for a specific wallet.
7. **Blockchain Ledger** — Shows all blocks in the chain with their hashes and transactions.

---

## 6. Results and Conclusion

### 6.1 Results
The Digital Wallet System was successfully implemented with the following features:

- ✅ **Wallet Creation** with unique auto-generated Wallet IDs
- ✅ **Secure PIN Authentication** using SHA-256 hashing (PINs are never stored in plain text)
- ✅ **Fund Deposits** from the SYSTEM account
- ✅ **Peer-to-Peer Transfers** with balance validation and PIN confirmation
- ✅ **Transaction History** displaying date, sender, receiver, and amount
- ✅ **Blockchain Ledger View** showing the complete chain of blocks with hash linkage
- ✅ **Data Persistence** — all wallets and blockchain data survive application restarts via `wallet_data.dat`
- ✅ **Balance Computation** derived from the full transaction chain (never stored as a number)

### 6.2 OOP Concepts Demonstrated

| Concept | Implementation |
|---------|---------------|
| **Classes & Objects** | `Transaction`, `Block`, `Ledger`, `Account`, `Wallet` |
| **Inheritance** | `Wallet` inherits `name` and `walletID` from `Account` |
| **Encapsulation** | `hashedPin` is private, only accessible through `verifyPin()` |
| **Abstraction** | Header files expose interface; `.cpp` files hide implementation |
| **Constructor Overloading** | Two constructors each for `Transaction` and `Block` |
| **Vectors (Dynamic Arrays)** | Used to store transactions and blockchain |
| **Maps (Dictionaries)** | Used for O(log N) wallet lookup by ID |
| **File Handling** | `ofstream`/`ifstream` for persistent data storage |

### 6.3 Conclusion
This project demonstrates the practical application of Object-Oriented Programming in building a real-world financial system. By combining OOP principles with cryptographic hashing and blockchain-inspired data structures, the system achieves security, data integrity, and persistence — the three pillars of any payment platform.

The use of SHA-256 ensures that sensitive data (PINs) is protected even if the underlying data file is compromised. The blockchain architecture guarantees that the transaction history is tamper-proof and auditable. The separation of interface (`.h`) and implementation (`.cpp`) files follows industry-standard C++ development practices.

---

## 7. References

1. NIST FIPS 180-4 — Secure Hash Standard (SHA-256 Algorithm Specification)  
   https://csrc.nist.gov/publications/detail/fips/180/4/final

2. Nakamoto, S. (2008). *Bitcoin: A Peer-to-Peer Electronic Cash System*  
   https://bitcoin.org/bitcoin.pdf

3. Stroustrup, B. (2013). *The C++ Programming Language* (4th Edition). Addison-Wesley.

4. C++ Reference — Standard Template Library (STL)  
   https://cplusplus.com/reference/

5. GeeksforGeeks — Object Oriented Programming in C++  
   https://www.geeksforgeeks.org/object-oriented-programming-in-cpp/

---

*Report generated for mid-semester submission — March 2026*
