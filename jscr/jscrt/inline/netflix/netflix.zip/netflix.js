document.getElementById("getStartedBtn").addEventListener("click", function() {
alert("Get started button clicked!");
});
